package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.Timer;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TelaPrincipal extends JFrame {

    // --- Estilos ---
    private static final Color COLOR_BG_CENTER = new Color(23, 23, 23);
    private static final Color COLOR_LEFT_BAR = new Color(10, 10, 10);
    private static final Color COLOR_TOP_BAR = new Color(18, 18, 18);
    private static final Color COLOR_SUB_BAR = new Color(32, 32, 32);
    private static final Color COLOR_TEXT = new Color(240, 240, 240);
    private static final Color COLOR_HOVER_BG = new Color(255, 157, 8);
    private static final Color COLOR_HOVER_TEXT = new Color(255, 255, 255);

    // --- Componentes ---
    private final JPanel painelConteudoCentral;
    private final JLabel logoCenter;

    public TelaPrincipal() {
        setTitle("Estacione+");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1024, 768));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_BG_CENTER);

        // Painel Esquerdo
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(COLOR_LEFT_BAR);
        left.setPreferredSize(new Dimension(100, 0));
        JLabel logoLeft = new JLabel(loadIcon("src/imagens/LogoEstacione+.png", 60, 50));
        logoLeft.setHorizontalAlignment(SwingConstants.CENTER);
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        logoPanel.setOpaque(false);
        logoPanel.add(logoLeft);
        left.add(logoPanel, BorderLayout.NORTH);
        add(left, BorderLayout.WEST);

        // Painel do Topo
        JPanel topWrapper = new JPanel(new BorderLayout());
        topWrapper.setBackground(COLOR_TOP_BAR);
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(COLOR_TOP_BAR);
        topBar.setPreferredSize(new Dimension(0, 54));
        topBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(45, 45, 45)));

        JPanel leftHead = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 15));
        leftHead.setOpaque(false);
        JLabel lbInicio = new JLabel("Início");
        lbInicio.setIcon(loadIcon("src/imagens/casa.png", 24, 24));
        lbInicio.setIconTextGap(8);
        lbInicio.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbInicio.setForeground(COLOR_TEXT);
        lbInicio.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lbInicio.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarPainelInicial();
            }
        });
        leftHead.add(lbInicio);
        topBar.add(leftHead, BorderLayout.WEST);
        
        // --- CORREÇÃO APLICADA AQUI ---
        // O espaçamento vertical (terceiro parâmetro) foi ajustado de 12 para 15,
        // para ficar idêntico ao painel da esquerda.
        JPanel rightHead = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        rightHead.setOpaque(false);
        JButton btnConfig = new JButton();
        btnConfig.setIcon(loadIcon("src/imagens/configuracao.png", 24, 24));
        btnConfig.setToolTipText("Configurações");
        btnConfig.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnConfig.setContentAreaFilled(false);
        btnConfig.setBorder(null);
        btnConfig.setFocusPainted(false);
        
        btnConfig.addActionListener(e -> {
            final JWindow popup = new JWindow(this);
            MenuConfiguracaoPanel menuPanel = new MenuConfiguracaoPanel(this, popup);
            popup.add(menuPanel);
            Point location = btnConfig.getLocationOnScreen();
            popup.setLocation(location.x - menuPanel.getPreferredSize().width + btnConfig.getWidth(), location.y + btnConfig.getHeight());
            popup.addWindowFocusListener(new WindowAdapter() {
                @Override
                public void windowLostFocus(WindowEvent e) {
                    popup.dispose();
                }
            });
            popup.pack();
            popup.setVisible(true);
        });
        rightHead.add(btnConfig);
        topBar.add(rightHead, BorderLayout.EAST);

        // Sub-bar
        JPanel subBar = new JPanel(new GridBagLayout());
        subBar.setBackground(COLOR_SUB_BAR);
        subBar.setPreferredSize(new Dimension(0, 50));
        GridBagConstraints gbcSubBar = new GridBagConstraints();
        gbcSubBar.gridy = 0;
        gbcSubBar.insets = new Insets(5, 10, 5, 10);
        gbcSubBar.anchor = GridBagConstraints.CENTER;
        gbcSubBar.fill = GridBagConstraints.NONE;

        RoundedButton btnRegistrarVeic = new RoundedButton("Registrar Veíc.");
        RoundedButton btnGerenciar = new RoundedButton("Gerenciar");
        RoundedButton btnConsultar = new RoundedButton("Consultar");
        RoundedButton btnRelatorios = new RoundedButton("Relatórios");
        RoundedButton btnInfos = new RoundedButton("Infos"); // --- NOVO ---

        // --- NOVO: Ordem atualizada para incluir o btnInfos ---
        RoundedButton[] buttons = {btnRegistrarVeic, btnGerenciar, btnConsultar, btnInfos, btnRelatorios};
        
        for (int i = 0; i < buttons.length; i++) {
            gbcSubBar.gridx = i;
            subBar.add(buttons[i], gbcSubBar);
        }

        btnRegistrarVeic.addActionListener(e -> trocarPainelCentral(new TelaEntradaVeiculo(this)));
        btnGerenciar.addActionListener(e -> trocarPainelCentral(new TelaGerenciarVeiculos(this)));
        btnConsultar.addActionListener(e -> trocarPainelCentral(new TelaConsultarVeiculo(this)));
        btnRelatorios.addActionListener(e -> trocarPainelCentral(new TelaRelatorios(this)));
        
        // --- NOVO: Ação para o novo botão ---
        // (Isso vai dar erro de compilação até criarmos a classe TelaInfosPatio)
        btnInfos.addActionListener(e -> trocarPainelCentral(new TelaInfosPatio(this)));

        topWrapper.add(topBar, BorderLayout.NORTH);
        topWrapper.add(subBar, BorderLayout.CENTER);
        add(topWrapper, BorderLayout.NORTH);

        // Painel Central
        painelConteudoCentral = new JPanel(new GridBagLayout());
        painelConteudoCentral.setBackground(COLOR_BG_CENTER);
        logoCenter = new JLabel(loadIcon("src/imagens/LogoEstacione+Escrita.png", 250, 250));
        add(painelConteudoCentral, BorderLayout.CENTER);
        
        mostrarPainelInicial();
    }

    public void trocarPainelCentral(JPanel novoPainel) {
        Component[] components = painelConteudoCentral.getComponents();
        if (components.length > 0 && components[0] instanceof TelaEntradaVeiculo) {
            ((TelaEntradaVeiculo) components[0]).stopCamera();
        }
    
        painelConteudoCentral.removeAll();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        painelConteudoCentral.add(novoPainel, gbc);

        painelConteudoCentral.revalidate();
        painelConteudoCentral.repaint();
    }

    public void mostrarPainelInicial() {
        Component[] components = painelConteudoCentral.getComponents();
        if (components.length > 0 && components[0] instanceof TelaEntradaVeiculo) {
            ((TelaEntradaVeiculo) components[0]).stopCamera();
        }
        
        painelConteudoCentral.removeAll();
        painelConteudoCentral.add(logoCenter, new GridBagConstraints());
        painelConteudoCentral.revalidate();
        painelConteudoCentral.repaint();
    }

    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new java.awt.image.BufferedImage(width, height,
                    java.awt.image.BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }
    
    private class RoundedButton extends JButton {
        private final Color baseBg = COLOR_SUB_BAR;
        private final Color baseFg = COLOR_TEXT;
        private Color targetBg, targetFg;
        private Timer timer;
        private final int steps = 10;
        private int currentStep;

        public RoundedButton(String text) {
            super(text);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setForeground(baseFg);
            setBackground(baseBg);
            setFocusPainted(false);
            setBorder(new EmptyBorder(8, 16, 8, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setContentAreaFilled(false);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { 
                    startAnimation(COLOR_HOVER_BG, COLOR_HOVER_TEXT); }
                @Override public void mouseExited(MouseEvent e) { 
                    startAnimation(baseBg, baseFg); }
            });
        }

        private void startAnimation(Color bg, Color fg) {
            if (timer != null && timer.isRunning()) timer.stop();
            targetBg = bg; targetFg = fg; currentStep = 0;
            Color startBg = getBackground();
            Color startFg = getForeground();
            timer = new Timer(20, e -> {
                float ratio = (float) currentStep / steps;
                setBackground(blendColor(startBg, targetBg, ratio));
                setForeground(blendColor(startFg, targetFg, ratio));
                currentStep++;
                if (currentStep > steps) ((Timer) e.getSource()).stop();
            });
            timer.start();
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    private Color blendColor(Color c1, Color c2, float ratio) {
        if (ratio > 1f) ratio = 1f; if (ratio < 0f) ratio = 0f;
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);
        return new Color(r, g, b);
    }
}