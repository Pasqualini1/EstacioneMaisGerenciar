package view;

import dto.VeiculoDTO;
import java.awt.BorderLayout;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class TelaRelatorioFinanceiro extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_GRAY_BUTTON = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_TOTAL = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes e Dados ---
    private final TelaPrincipal telaPrincipal;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;
    private final List<VeiculoDTO> dadosDoRelatorio;
    private final LocalDateTime dataInicioPeriodo;
    private final LocalDateTime dataFimPeriodo;

    public TelaRelatorioFinanceiro(TelaPrincipal telaPrincipal, List<VeiculoDTO> dados, LocalDateTime dataInicio, LocalDateTime dataFim) {
        this.telaPrincipal = telaPrincipal;
        this.dadosDoRelatorio = dados;
        this.dataInicioPeriodo = dataInicio;
        this.dataFimPeriodo = dataFim;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        String[] colunas = {"Placa", "Entrada", "Saída", "Valor Pago"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        popularTabela(dadosDoRelatorio);
    }

    private void visualizarComoPdf() {
        JDialog loadingDialog = createLoadingDialog("Gerando PDF...");
        SwingWorker<byte[], Void> worker = new SwingWorker<>() {
            @Override
            protected byte[] doInBackground() throws Exception {
                BigDecimal total = calcularTotal(dadosDoRelatorio);
                return gerarPdfFinanceiroBytes(dadosDoRelatorio, dataInicioPeriodo, dataFimPeriodo, total);
            }
            @Override
            protected void done() {
                loadingDialog.dispose();
                try {
                    byte[] pdfBytes = get();
                    // --- CORREÇÃO APLICADA AQUI: Passando o nome do arquivo ---
                    TelaVisualizadorPdf pdfViewer = new TelaVisualizadorPdf(telaPrincipal, pdfBytes, "Relatorio_Financeiro.pdf");
                    telaPrincipal.trocarPainelCentral(pdfViewer);
                } catch (Exception e) {
                    e.printStackTrace();
                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(TelaRelatorioFinanceiro.this), "Erro", "Ocorreu um erro ao gerar o PDF.");
                }
            }
        };
        worker.execute();
        loadingDialog.setVisible(true);
    }

    private byte[] gerarPdfFinanceiroBytes(List<VeiculoDTO> dados, LocalDateTime dataInicio, LocalDateTime dataFim, BigDecimal totalArrecadado) throws IOException {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            PDImageXObject logoImage = null;
            try (InputStream in = getClass().getResourceAsStream("/Logo Estacione+ Preta.png")) {
                if (in != null) {
                    logoImage = PDImageXObject.createFromByteArray(document, in.readAllBytes(), "logo");
                }
            } catch (Exception e) {
                System.err.println("Erro ao carregar a imagem da logo: " + e.getMessage());
            }

            float margin = 50;
            float yStart = page.getMediaBox().getHeight() - margin;
            float pageWidth = page.getMediaBox().getWidth();
            
            // --- CABEÇALHO CORRIGIDO: logo à esquerda, título e período centralizados ---
            if (logoImage != null) {
                contentStream.drawImage(logoImage, margin, yStart - 60, 80, 80);
            }

            String titulo = "Relatório Financeiro";
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
            float tituloWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(titulo) / 1000 * 16;
            float tituloX = (pageWidth - tituloWidth) / 2;
            contentStream.beginText();
            contentStream.newLineAtOffset(tituloX, yStart - 15);
            contentStream.showText(titulo);
            contentStream.endText();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String textPeriodo = "Período: " + dataInicio.format(formatter) + " até " + dataFim.format(formatter);
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            float periodoWidth = PDType1Font.HELVETICA.getStringWidth(textPeriodo) / 1000 * 12;
            float periodoX = (pageWidth - periodoWidth) / 2;
            contentStream.beginText();
            contentStream.newLineAtOffset(periodoX, yStart - 35);
            contentStream.showText(textPeriodo);
            contentStream.endText();
            // --- FIM CABEÇALHO ---
            
            float yPosition = yStart - 80;
            int pageNum = 1;

            final String[] headers = {"Placa", "Entrada", "Saída", "Valor Pago"};
            final float[] colWidths = {100, 150, 150, 100};

            drawTableHeader(contentStream, yPosition, colWidths, headers);
            yPosition -= 30;

            DateTimeFormatter dataFormatter = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm");
            for (VeiculoDTO veiculo : dados) {
                if (yPosition < margin + 30) {
                    contentStream.close();
                    drawPageNumber(document, page, pageNum++);
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = yStart - 80; // Reset Y
                    drawTableHeader(contentStream, yPosition, colWidths, headers);
                    yPosition -= 30;
                }
                
                String[] rowData = {
                    veiculo.placa(),
                    veiculo.horarioEntrada().format(dataFormatter),
                    veiculo.horarioSaida() != null ? veiculo.horarioSaida().format(dataFormatter) : "N/A",
                    formatarValor(veiculo.valorTotal())
                };
                drawTableRow(contentStream, yPosition, margin, colWidths, rowData);
                yPosition -= 20;
            }
            
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
            String totalText = "Total Arrecadado no Período: " + formatarValor(totalArrecadado);
            float textWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(totalText) / 1000 * 12;
            float tableWidth = 0; for(float w : colWidths) { tableWidth += w; }
            float tableX = (page.getMediaBox().getWidth() - tableWidth) / 2;
            contentStream.newLineAtOffset(tableX + tableWidth - textWidth, yPosition - 20);
            contentStream.showText(totalText);
            contentStream.endText();

            drawPageNumber(document, page, pageNum);
            contentStream.close();
            
            document.save(outputStream);
            return outputStream.toByteArray();
        }
    }

    private void drawTableHeader(PDPageContentStream contentStream, float y, float[] colWidths, String[] headers) throws IOException {
        contentStream.setStrokingColor(Color.DARK_GRAY);
        contentStream.setNonStrokingColor(new Color(230, 230, 230));
        float tableWidth = 0; for (float width : colWidths) { tableWidth += width; }
        float tableX = (PDRectangle.A4.getWidth() - tableWidth) / 2;
        contentStream.addRect(tableX, y - 15, tableWidth, 20);
        contentStream.fillAndStroke();
        
        contentStream.setNonStrokingColor(Color.BLACK);
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
        float x = tableX + 5;
        for (int i = 0; i < headers.length; i++) {
            contentStream.beginText();
            contentStream.newLineAtOffset(x, y - 10);
            contentStream.showText(headers[i]);
            contentStream.endText();
            x += colWidths[i];
        }
    }

    private void drawTableRow(PDPageContentStream contentStream, float y, float margin, float[] colWidths, String[] rowData) throws IOException {
        contentStream.setNonStrokingColor(Color.BLACK);
        contentStream.setFont(PDType1Font.HELVETICA, 9);
        float tableWidth = 0; for (float width : colWidths) { tableWidth += width; }
        float tableX = (PDRectangle.A4.getWidth() - tableWidth) / 2;
        float x = tableX + 5;

        for (int i = 0; i < rowData.length; i++) {
            String text = rowData[i] != null ? rowData[i] : "";
            contentStream.beginText();
            contentStream.newLineAtOffset(x, y);
            contentStream.showText(text);
            contentStream.endText();
            x += colWidths[i];
        }
    }

    private void drawPageNumber(PDDocument doc, PDPage page, int pageNum) throws IOException {
        try (PDPageContentStream contentStream = new PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true)) {
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 10);
            contentStream.newLineAtOffset(page.getMediaBox().getWidth() / 2 - 30, 30);
            contentStream.showText("Página " + pageNum);
            contentStream.endText();
        }
    }
    
    private BigDecimal calcularTotal(List<VeiculoDTO> dados) {
        BigDecimal total = BigDecimal.ZERO;
        if (dados != null) {
            for (VeiculoDTO v : dados) {
                if (v.valorTotal() != null) {
                    total = total.add(v.valorTotal());
                }
            }
        }
        return total;
    }
    
    private JDialog createLoadingDialog(String message) {
        JDialog dialog = new JDialog(telaPrincipal, "Aguarde...", true);
        JLabel label = new JLabel(message);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(new EmptyBorder(20, 20, 20, 20));
        dialog.add(label);
        dialog.pack();
        dialog.setLocationRelativeTo(telaPrincipal);
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        return dialog;
    }

    private void popularTabela(List<VeiculoDTO> dados) {
        if (dados == null) return;
        for (VeiculoDTO v : dados) {
            modeloTabela.addRow(new Object[]{
                    v.placa(),
                    formatarData(v.horarioEntrada()),
                    formatarData(v.horarioSaida()),
                    formatarValor(v.valorTotal())
            });
        }
    }

    private String formatarData(LocalDateTime data) {
        if (data == null) return "N/A";
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"));
    }

    private String formatarValor(BigDecimal valor) {
        if (valor == null) {
            valor = BigDecimal.ZERO;
        }
        return NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(valor);
    }

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createTableScrollPane(), BorderLayout.CENTER);
        panel.add(createFooterPanel(), BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String periodo = dataInicioPeriodo.format(formatter) + " a " + dataFimPeriodo.format(formatter);
        JLabel lblTitulo = new JLabel("Relatório Financeiro");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        JLabel lblSubtitulo = new JLabel(periodo);
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSubtitulo.setForeground(new Color(180, 180, 180));
        JPanel titleTextPanel = new JPanel();
        titleTextPanel.setOpaque(false);
        titleTextPanel.setLayout(new BoxLayout(titleTextPanel, BoxLayout.Y_AXIS));
        titleTextPanel.add(lblTitulo);
        titleTextPanel.add(lblSubtitulo);
        panelTitulo.add(titleTextPanel, BorderLayout.WEST);
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);
        RoundedButton btnPdf = new RoundedButton("Visualizar em PDF");
        btnPdf.setBackground(COLOR_ACCENT);
        btnPdf.addActionListener(e -> visualizarComoPdf());
        RoundedButton btnVoltar = new RoundedButton("Voltar");
        btnVoltar.setBackground(COLOR_GRAY_BUTTON);
        btnVoltar.addActionListener(e -> telaPrincipal.trocarPainelCentral(new TelaRelatorios(telaPrincipal)));
        buttonsPanel.add(btnPdf);
        buttonsPanel.add(btnVoltar);
        panelTitulo.add(buttonsPanel, BorderLayout.EAST);
        return panelTitulo;
    }

    private JScrollPane createTableScrollPane() {
        styleTable();
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL);
        return scrollPane;
    }

    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        BigDecimal total = calcularTotal(dadosDoRelatorio);
        JLabel lblTotal = new JLabel("Total Arrecadado no Período: " + formatarValor(total));
        lblTotal.setFont(FONT_TOTAL);
        lblTotal.setForeground(COLOR_ACCENT);
        footerPanel.add(lblTotal);
        return footerPanel;
    }

    private void styleTable() {
        tabela.setRowHeight(40);
        tabela.setFont(FONT_ROW);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setBackground(COLOR_PANEL);
        tabela.setGridColor(COLOR_BACKGROUND);
        tabela.setSelectionBackground(COLOR_ACCENT.darker());
        tabela.setSelectionForeground(Color.WHITE);
        tabela.setShowVerticalLines(false);
        JTableHeader header = tabela.getTableHeader();
        header.setBackground(COLOR_BACKGROUND);
        header.setForeground(COLOR_ACCENT);
        header.setFont(FONT_HEADER);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 40));
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        tabela.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
    }

    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_GRAY_BUTTON;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) { if (isEnabled()) setBackground(hoverBg); }
                public void mouseExited(java.awt.event.MouseEvent evt) { setBackground(defaultBg); }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}