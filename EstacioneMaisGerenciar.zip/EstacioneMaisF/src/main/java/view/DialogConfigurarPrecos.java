package view;

import dto.PrecoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Janela de diálogo para o usuário configurar a tabela de preços do estacionamento,
 * com um modelo simples de dois campos e estilo profissional.
 */
public class DialogConfigurarPrecos extends JDialog {

    // --- Estilos Profissionais Finais ---
    private static final Color COLOR_CARD_BG = new Color(45, 45, 45);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_TEXT_SECONDARY = new Color(150, 150, 150);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_GRAY_BUTTON = new Color(108, 117, 125);
    private static final Color COLOR_INPUT_BG = new Color(34, 40, 49);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 20);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes da UI ---
    private final JFormattedTextField txtPrecoValor;
    private final JTextField txtPrecoMinutos;
    private final Frame owner;

    public DialogConfigurarPrecos(Frame owner) {
        super(owner, "Configurar Preço do Estacionamento", true);
        this.owner = owner;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 25));
        mainPanel.setBackground(COLOR_CARD_BG);
        mainPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        // --- Painel do Título ---
        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Definir Preço por Fração de Tempo");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel lblSubtitulo = new JLabel("Defina o valor e o intervalo de tempo para a cobrança.");
        lblSubtitulo.setFont(FONT_LABEL);
        lblSubtitulo.setForeground(COLOR_TEXT_SECONDARY);
        lblSubtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        titlePanel.add(lblTitulo);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 5)));
        titlePanel.add(lblSubtitulo);
        mainPanel.add(titlePanel, BorderLayout.NORTH);

        // --- Painel de Inputs com Layout Vertical ---
        JPanel inputPanel = new JPanel();
        inputPanel.setOpaque(false);
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

        NumberFormat currencyFormat = NumberFormat.getNumberInstance(new Locale("pt", "BR"));
        currencyFormat.setMinimumFractionDigits(2);
        currencyFormat.setMaximumFractionDigits(2);

        // --- Campo Valor ---
        inputPanel.add(createLabel("Valor a ser cobrado (R$):"));
        inputPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        txtPrecoValor = new JFormattedTextField(currencyFormat);
        styleTextField(txtPrecoValor);
        inputPanel.add(txtPrecoValor);
        
        inputPanel.add(Box.createRigidArea(new Dimension(0, 15))); // Espaçamento

        // --- Campo Minutos ---
        inputPanel.add(createLabel("A cada (minutos):"));
        inputPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        txtPrecoMinutos = new JTextField();
        styleTextField(txtPrecoMinutos);
        inputPanel.add(txtPrecoMinutos);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        // --- Painel de Botões ---
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);
        RoundedDialogButton btnCancelar = new RoundedDialogButton("Cancelar", COLOR_GRAY_BUTTON);
        btnCancelar.addActionListener(e -> dispose());
        RoundedDialogButton btnSalvar = new RoundedDialogButton("Salvar", COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarConfiguracoes());
        buttonsPanel.add(btnCancelar);
        buttonsPanel.add(btnSalvar);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);

        getContentPane().setBackground(COLOR_CARD_BG);
        add(mainPanel);
        pack();
        setLocationRelativeTo(owner);
        carregarConfiguracoes();
    }

    private void carregarConfiguracoes() {
        SwingWorker<PrecoDTO, Void> worker = new SwingWorker<>() {
            @Override
            protected PrecoDTO doInBackground() throws ApiException {
                // --- CORREÇÃO APLICADA AQUI ---
                // O método foi renomeado de getConfiguracao para getPreco no ApiClient
                return ApiClient.getPreco();
            }

            @Override
            protected void done() {
                try {
                    PrecoDTO config = get();
                    txtPrecoValor.setValue(config.precoValor());
                    txtPrecoMinutos.setText(String.valueOf(config.precoMinutos()));
                } catch (Exception e) {
                    DialogoCustomizado.mostrarMensagemErro(owner, "Erro de Comunicação", "Não foi possível carregar as configurações de preço.");
                    dispose();
                }
            }
        };
        worker.execute();
    }

    private void salvarConfiguracoes() {
        try {
            BigDecimal precoValor = new BigDecimal(((Number) txtPrecoValor.getValue()).toString().replace(",", "."));
            int precoMinutos = Integer.parseInt(txtPrecoMinutos.getText().trim());

            if (precoValor.compareTo(BigDecimal.ZERO) < 0 || precoMinutos <= 0) {
                String mensagem = "Os valores não podem ser negativos.\nOs minutos devem ser maiores que zero.";
                DialogoCustomizado.mostrarMensagemErro(owner, "Erro de Validação", mensagem);
                return;
            }

            PrecoDTO dto = new PrecoDTO(precoValor, precoMinutos);

            SwingWorker<Void, Void> worker = new SwingWorker<>() {
                @Override
                protected Void doInBackground() throws ApiException {
                    // --- CORREÇÃO APLICADA AQUI ---
                    // O método foi renomeado de saveConfiguracao para savePreco no ApiClient
                    ApiClient.savePreco(dto);
                    return null;
                }

                @Override
                protected void done() {
                    try {
                        get();
                        DialogoCustomizado.mostrarMensagemSucesso(owner, "Sucesso", "Configurações de preço salvas com sucesso!");
                        dispose();
                    } catch (Exception e) {
                        DialogoCustomizado.mostrarMensagemErro(owner, "Erro ao Salvar", "Não foi possível salvar as configurações no servidor.");
                    }
                }
            };
            worker.execute();

        } catch (NumberFormatException | NullPointerException e) {
            DialogoCustomizado.mostrarMensagemErro(owner, "Erro de Formato", "Por favor, preencha todos os campos com valores numéricos válidos.");
        }
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_LABEL);
        label.setForeground(COLOR_TEXT_PRIMARY);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void styleTextField(JTextField field) {
        field.setFont(FONT_LABEL);
        field.setBackground(COLOR_INPUT_BG);
        field.setForeground(COLOR_TEXT_PRIMARY);
        field.setCaretColor(COLOR_ORANGE_ACCENT);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(80,80,80)), // Borda sutil
            new EmptyBorder(10, 10, 10, 10)
        ));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, field.getPreferredSize().height));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private static class RoundedDialogButton extends JButton {
        private final Color baseBg;
        private final Color hoverBg;
        public RoundedDialogButton(String text, Color bgColor) {
            super(text);
            this.baseBg = bgColor;
            this.hoverBg = bgColor.brighter();
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setBackground(baseBg);
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setContentAreaFilled(false);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { setBackground(hoverBg); }
                @Override public void mouseExited(MouseEvent e) { setBackground(baseBg); }
            });
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}