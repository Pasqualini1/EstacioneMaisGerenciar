package com.estacioneMais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstacioneMaisApplication {
	public static void main(String[] args) {
		SpringApplication.run(EstacioneMaisApplication.class, args);
	}
}